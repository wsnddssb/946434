#include "Initial.h"

class Powershell
{
public:
	Powershell(void);
	~Powershell(void);

	bool StartCmd(const string& process);
	bool ShutDownCmd(void);
	bool GetOutput(const string& endStr, int timeout, string& outstr);//Getoutput string
	bool Input(const string& cmd);//exec cmd
private:
	HANDLE m_hChildInputWrite;	//Redirect child process input handle
	HANDLE m_hChildInputRead;
	HANDLE m_hChildOutputWrite;	//Redirect child process output handle 
	HANDLE m_hChildOutputRead;
	PROCESS_INFORMATION pi;//cmd Info
};