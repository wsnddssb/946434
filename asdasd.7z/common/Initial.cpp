#include "Initial.h"


bool InitialWincock()
{
	//Initialize Winsock2 Lib
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	wVersionRequested = MAKEWORD(1, 1);
	err = WSAStartup(wVersionRequested, &wsaData);
	if (err != 0)
	{
		cerr << "WSAStartup Failed!" << endl;
		WSACleanup();
		return false;
	}
	if (LOBYTE(wsaData.wVersion) != 1 || HIBYTE(wsaData.wVersion) != 1) {
		WSACleanup();
		return false;
	}
	return true;
}

bool Verify_cert(int nFlag, SSL_CTX* sslContext, const char* szCacert, const char* szCertf, const char* szKeyf)
{
	if (nFlag == SERVER_ONLY)
	{
		SSL_CTX_set_verify(sslContext, SSL_VERIFY_NONE, NULL);
		return true;
	}
	else
	{
		SSL_CTX_set_verify(sslContext, SSL_VERIFY_NONE, NULL);//verify or not
		SSL_CTX_load_verify_locations(sslContext, szCacert, NULL);//CA for verify
		//Load CERT & PRIVATE KEY
		if (!SSL_CTX_use_certificate_file(sslContext, szCertf, SSL_FILETYPE_PEM))
		{
			ERR_print_errors_fp(stderr);
			SSL_CTX_free(sslContext);
			WSACleanup();
			return false;
		}
		if (!SSL_CTX_use_PrivateKey_file(sslContext, szKeyf, SSL_FILETYPE_PEM))
		{
			ERR_print_errors_fp(stderr);
			SSL_CTX_free(sslContext);
			WSACleanup();
			return false;
		}
		if (!SSL_CTX_check_private_key(sslContext))
		{
			cerr << "SSL_CTX_check_private_key failed." << endl;
			SSL_CTX_free(sslContext);
			WSACleanup();
			return false;
		}
		return true;
	}
	return false;
}

void handle_error(const char* file, int line, const char* msg)
{

	fprintf(stderr, " %s :%d %s \n", file, line, msg);
	ERR_print_errors_fp(stderr);
	return;
}