#ifndef _AES_CBC256_H_
#include "AES_CBC256.h"

#endif

AES_CBC256::AES_CBC256() {
    memcpy(m_userKey, "XZJE151628AED2A6ABF7158809CF4F3C2B7E151628AED2A6ABF7158809CF4FTP", USER_KEY_LENGTH);
    memcpy(m_ivec, "XZJ2030405060708090A0B0C0D0E0FTP", IVEC_LENGTH);  // Vector initialization

}
AES_CBC256::~AES_CBC256() {

}

bool AES_CBC256::AES_CBC256_Encrypt(const unsigned char* in, unsigned char* out, size_t length) {

    if (0 != (length % AES_BLOCK_SIZE)) {
        MessageBox(0, "the length is not multiple of AES_BLOCK_SIZE(16bytes)", 0, 0);
        return false;
    }
    unsigned char ivec[IVEC_LENGTH];
    memcpy(ivec, m_ivec, IVEC_LENGTH);
    AES_KEY key;
    // get the key with userkey
    if (AES_set_encrypt_key(m_userKey, BITS_LENGTH, &key) < 0) {
        MessageBox(0, "get the key error", 0, 0);
        return false;
    }
 

    AES_cbc_encrypt(in, out, length, &key, ivec, AES_ENCRYPT);
    return true;
}

bool AES_CBC256::AES_CBC256_Decrypt(const unsigned char* in, unsigned char* out, size_t length) {

    if (0 != (length % AES_BLOCK_SIZE)) {
        MessageBox(0, "the length is not multiple of AES_BLOCK_SIZE(16bytes)", 0, 0);
        return false;
    }
    unsigned char ivec[IVEC_LENGTH];
    memcpy(ivec, m_ivec, IVEC_LENGTH);
    AES_KEY key;
    // get the key with userkey
    if (AES_set_decrypt_key(m_userKey, BITS_LENGTH, &key) < 0) {
        MessageBox(0, "get the key error", 0, 0);
        return false;
    }
    AES_cbc_encrypt(in, out, length, &key, ivec, AES_DECRYPT);
    return true;
}


int AES_CBC256::SSL_AES256_sendData(AES_CBC256 m_pcAES_CBC256, PC_INFO pc_info, SSL* sslHandle)
{
    size_t length = 0;
    if (0 == (sizeof(pc_info) % AES_BLOCK_SIZE)) {
        length = sizeof(pc_info);
    }
    else {
        length = sizeof(pc_info) + (AES_BLOCK_SIZE - sizeof(pc_info) % AES_BLOCK_SIZE);
    }
    unsigned char* encrypt_in_data = new unsigned char[sizeof(pc_info)];
    unsigned char* encrypt_out_data = new unsigned char[length];
    memcpy(encrypt_in_data, &pc_info, sizeof(pc_info));
    // encrypt
    bool encrypt_ret = m_pcAES_CBC256.AES_CBC256_Encrypt(encrypt_in_data, encrypt_out_data, length);

    if (false == encrypt_ret) {
      //  printf("encrypt error!\n");
        return -1;
    }
    else {
        //printf("encrypt successful!\n");
        int bytesSent = SSL_write(sslHandle, encrypt_out_data, length);
        return bytesSent;

    }
    if (encrypt_in_data != nullptr)
    {
        delete encrypt_in_data;
        encrypt_in_data = nullptr;
    }

    if (encrypt_out_data != nullptr)
    {
        delete encrypt_out_data;
        encrypt_out_data = nullptr;
    }

}

int AES_CBC256::SSL_AES256_sendData(AES_CBC256 m_pcAES_CBC256, Data Data, SSL* sslHandle)
{
    size_t length = 0;
    if (0 == (sizeof(Data) % AES_BLOCK_SIZE)) {
        length = sizeof(Data);
    }
    else {
        length = sizeof(Data) + (AES_BLOCK_SIZE - sizeof(Data) % AES_BLOCK_SIZE);
    }
    unsigned char* encrypt_in_data = new unsigned char[sizeof(Data)];
    unsigned char* encrypt_out_data = new unsigned char[length];
    memcpy(encrypt_in_data, &Data, sizeof(Data));
    // encrypt
    bool encrypt_ret = m_pcAES_CBC256.AES_CBC256_Encrypt(encrypt_in_data, encrypt_out_data, length);

    if (false == encrypt_ret) {
        if (encrypt_in_data != nullptr)
        {
            delete encrypt_in_data;
            encrypt_in_data = nullptr;
        }

        if (encrypt_out_data != nullptr)
        {
            delete encrypt_out_data;
            encrypt_out_data = nullptr;
        }

        return -1;
    }
    else {
        int bytesSent = SSL_write(sslHandle, encrypt_out_data, length);
        if (encrypt_in_data != nullptr)
        {
            delete encrypt_in_data;
            encrypt_in_data = nullptr;
        }

        if (encrypt_out_data != nullptr)
        {
            delete encrypt_out_data;
            encrypt_in_data = nullptr;
        }

        return bytesSent;

    }


}

int AES_CBC256::SSL_AES256_recvData(AES_CBC256 m_pcAES_CBC256, PC_INFO* pc_info, SSL* sslHandle)
{

    char buffer[4096] = { 0 };
    mutex g_mutex;
    lock_guard<mutex> lock(g_mutex);
     int bytesRecv = SSL_read(sslHandle, buffer, sizeof(buffer) - 1);
     if (bytesRecv > 0) {

         //decrypt
         unsigned char* decrypt_out_data = new unsigned char[bytesRecv];
         bool decrypt_ret = m_pcAES_CBC256.AES_CBC256_Decrypt((unsigned char*)buffer, decrypt_out_data, bytesRecv);
         if (false == decrypt_ret) {
             if (decrypt_out_data != nullptr)
             {
                 delete decrypt_out_data;
                 decrypt_out_data = nullptr;
             }
             return -1;
         }
         else {
             memcpy(pc_info, decrypt_out_data, sizeof(PC_INFO));
             if (decrypt_out_data != nullptr)
             {
                 delete decrypt_out_data;
                 decrypt_out_data = nullptr;
             }
             return bytesRecv;
         }

     }
}

int AES_CBC256::SSL_AES256_recvData(AES_CBC256 m_pcAES_CBC256, Data* data, SSL* sslHandle)
{
    char buffer[4096]={0};
    mutex g_mutex;
    lock_guard<mutex> lock(g_mutex);
    int bytesRecv = SSL_read(sslHandle, buffer, sizeof(buffer) - 1);
    if (bytesRecv > 0) {

        //decrypt
        unsigned char* decrypt_out_data = new unsigned char[bytesRecv];
        bool decrypt_ret = m_pcAES_CBC256.AES_CBC256_Decrypt((unsigned char*)buffer, decrypt_out_data, bytesRecv);
        if (false == decrypt_ret) {
            return -1;
            if (decrypt_out_data != nullptr)
            {
                delete decrypt_out_data;
                decrypt_out_data = nullptr;
            }

        }
        else {

            memcpy(data, decrypt_out_data, sizeof(Data));
            if (decrypt_out_data != nullptr)
            {
                delete decrypt_out_data;
                decrypt_out_data = nullptr;
            }
            return bytesRecv;
        }

    }
}
