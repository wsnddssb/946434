
// RemoteCtrlDlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "RemoteCtrl.h"
#include "RemoteCtrlDlg.h"
#include "afxdialogex.h"

#include <AES_CBC256.h>
#include "SSLServer.h"
#define CERTF   "server.crt" 
#define KEYF   "server.key" 
#define CACERT "ca.crt"
#define CLIENT_PORT 0x3039//12345


extern "C"
{
#include <openssl/applink.c>
};

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


//Column Client/Info length
int nColumnClient = 7;
int nColumnInfo = 2;

//Initial width
int nColumnClient_length = 0;
int nColumnInfo_length = 0;

//Store column's name/width
typedef struct
{
	char* szTitle;
	int	  nWidth;
}Column_TypeDef;

//initial column data
Column_TypeDef aColumn_Client[] = {
	{"ID", 		        60	},
	{"IP", 		        100	},
	{"OS",		        100	},
	{"CPU",		        100	},
	{"DISK", 	        300	},
	{"PC_NAME",	        200	},
	{"CURRENT_USER",	200	}
};

Column_TypeDef aColumn_Info[] = {
	{"Information",		400	},
	{"OnlineTime",			800	},
};


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
	
END_MESSAGE_MAP()


// CRemoteCtrlDlg dialog



CRemoteCtrlDlg::CRemoteCtrlDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_REMOTECTRL_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRemoteCtrlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, LIST_CLIENT, m_CListCtrl_Client);
	DDX_Control(pDX, LIST_INFO, m_CListCtrl_Info);
}

BEGIN_MESSAGE_MAP(CRemoteCtrlDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_MESSAGE(WM_CLIENTONLINE, ClientLogin)
	ON_BN_CLICKED(BT_START, &CRemoteCtrlDlg::OnBnClickedStart)
	ON_NOTIFY(NM_RCLICK, LIST_CLIENT, &CRemoteCtrlDlg::OnRclickListClient)

	ON_COMMAND(FILETRANS, &CRemoteCtrlDlg::OnFiletrans)
	ON_COMMAND(DOWNLOAD, &CRemoteCtrlDlg::OnDownload)
END_MESSAGE_MAP()


// CRemoteCtrlDlg message handlers

BOOL CRemoteCtrlDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon



	// TODO: Add extra initialization here
	//InsertColumn
	InitialList();
	//InitialWincock
	if (!InitialWincock())
	{
		MessageBox("InitialWincock Failed", 0, 0);
	}
	//Initial MainWindow to toggle WM_SIZE
	CRect rect;
	GetWindowRect(&rect);
	rect.bottom += 200;
	MoveWindow(rect);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRemoteCtrlDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRemoteCtrlDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRemoteCtrlDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}




void CRemoteCtrlDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	int i;
	double dcx = cx;

   //Minisize return
	if (SIZE_MINIMIZED == nType)
	{
		return;
	}

	if (m_CListCtrl_Client.m_hWnd != NULL)
	{
		
		CRect rect;

		//Adjust the width and height of the list based on the width and height of the current mainwindow
		rect.left = 1;       //column up down left right
		rect.top = 80;       
		rect.right = cx - 1;  
		rect.bottom = cy - 200;  
		//rechange listctrl window
		m_CListCtrl_Client.MoveWindow(rect);

		//Base of MainWindow's changing to change
		for (i = 0; i < nColumnClient; i++)
		{
			double dd = aColumn_Client[i].nWidth;     //current column's width
			dd /= nColumnClient_length;                    //Take a look at the current width as a fraction of the total length
			dd *= dcx;                                       //Multiply the original length by the fraction to get the current width
			int NewWidth = (int)dd;                                  
			m_CListCtrl_Client.SetColumnWidth(i, NewWidth);
		}
	}

	if (m_CListCtrl_Info.m_hWnd != NULL)
	{

		CRect rect;

		//Adjust the width and height of the list based on the width and height of the current mainwindow
		rect.left = 1;        //column up down left right
		rect.top = cy - 200;  
		rect.right = cx - 1;  
		rect.bottom = cy - 20;
		//rechange listctrl window
		m_CListCtrl_Info.MoveWindow(rect);

		//Base of MainWindow's changing to change
		for (i = 0; i < nColumnClient; i++)
		{
			double dd = aColumn_Client[i].nWidth;     //current column's width
			dd /= nColumnClient_length;                    //Take a look at the current width as a fraction of the total length
			dd *= dcx;                                       //Multiply the original length by the fraction to get the current width
			int NewWidth = (int)dd;
			m_CListCtrl_Info.SetColumnWidth(i, NewWidth);
		}
	}
}


void CRemoteCtrlDlg::InitialList()
{
	//select full line
	m_CListCtrl_Client.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	m_CListCtrl_Info.SetExtendedStyle(LVS_EX_FULLROWSELECT);

	//InsertColumn and left
	int i = 0;

	for (i = 0; i < nColumnClient; i++)
	{
		m_CListCtrl_Client.InsertColumn(i, aColumn_Client[i].szTitle, LVCFMT_CENTER, aColumn_Client[i].nWidth);
		nColumnClient_length += aColumn_Client[i].nWidth;
	}

	for (i = 0; i < nColumnInfo; i++)
	{
		m_CListCtrl_Info.InsertColumn(i, aColumn_Info[i].szTitle, LVCFMT_CENTER, aColumn_Info[i].nWidth);
		nColumnInfo_length += aColumn_Info[i].nWidth;
	}

	return ;
}

int nLine = 0;
afx_msg LRESULT  CRemoteCtrlDlg::ClientLogin(WPARAM wParam,LPARAM lParam)
{
	// TODO: Add your implementation code here.
	PC_INFO* pc_info = (PC_INFO*)lParam;
	string strIP = (char*)wParam;
	int nSocketInfo = lParam;
	int nItem = m_CListCtrl_Client.InsertItem(nLine, to_string(nLine).c_str());
	m_CListCtrl_Client.SetItemText(nLine, 1, strIP.c_str());//IP
	m_CListCtrl_Client.SetItemText(nLine, 2, pc_info->szOS);//OS
	m_CListCtrl_Client.SetItemText(nLine, 3, pc_info->szCPU);//CPU
	m_CListCtrl_Client.SetItemText(nLine, 4, pc_info->szDISK);//DISK
	m_CListCtrl_Client.SetItemText(nLine, 5, pc_info->szPC_NAME);//PC_NAME
	m_CListCtrl_Client.SetItemText(nLine, 6, pc_info->szCURRENT_USER);//CURRENT_USER
	nLine++;
	return true;
}

void CRemoteCtrlDlg::OnBnClickedStart()
{
	//Start Server
	SSLConnection * server = new SSLConnection(8888);
	CWnd* pWnd = GetDlgItem(BT_START);
	pWnd->EnableWindow(FALSE);
	// TODO: Add your control notification handler code here
}


void CRemoteCtrlDlg::OnRclickListClient(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	int nCurrentSel = m_CListCtrl_Client.GetSelectedCount();
	if (nCurrentSel <= 0)
		return;
	

	CMenu popMenu;
	VERIFY(popMenu.LoadMenu(IDR_MENU1));
	CMenu* p = popMenu.GetSubMenu(0);
	ASSERT(p != NULL);
	CPoint	point;
	GetCursorPos(&point);
	p->TrackPopupMenu(TPM_LEFTALIGN | TPM_LEFTBUTTON, point.x, point.y, this);
	*pResult = 0;
}

mutex mt;
void CRemoteCtrlDlg::OnFiletrans()
{
	BOOL bRet = FALSE;
    CFileManger* pFile = NULL;
	CString cstrTemp = m_CListCtrl_Client.GetItemText(m_CListCtrl_Client.GetSelectionMark(), 1);
	if (!pFile)
	{
		pFile = new CFileManger();
		
	}

	if (!pFile->m_hWnd || !::IsWindow(pFile->m_hWnd))
	{
		bRet = pFile->Create(DLG_FILE, AfxGetMainWnd());
	}

	if (pFile->m_hWnd && ::IsWindow(pFile->m_hWnd))
	{
		pFile->SetWindowText(cstrTemp);
		pFile->ShowWindow(SW_SHOW);
	}


	lock_guard<mutex> guard(mt);
	AES_CBC256 aes_send;
	Data data = { 1,"FileBrose" };
	int nLine = m_CListCtrl_Client.GetSelectionMark();//get select line
	CString strTemp = m_CListCtrl_Client.GetItemText(nLine, 1);

	//compare sslhandle to send
	for (auto i : g_mapSSLHandle_IP)
	{
		string vstr(strTemp.GetBuffer(strTemp.GetLength() + 1));
		if (i.second == vstr)
		{
		
			aes_send.SSL_AES256_sendData(aes_send, data, i.first);
			break;
		}
	}

}


void CRemoteCtrlDlg::OnDownload()
{
	//send download
}
