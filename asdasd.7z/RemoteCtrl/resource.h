//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RemoteCtrl.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REMOTECTRL_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDD_DIALOG1                     131
#define DLG_FILE                        133
#define LIST_INFO                       1002
#define LIST_CLIENT                     1003
#define IDC_BUTTON1                     1004
#define BT_START                        1004
#define BT_                             1004
#define BT_UP                           1004
#define EDT_PATH                        1005
#define IDC_LIST1                       1006
#define LIST_FILE                       1006
#define ID_FILE_GENERATE                32771
#define FILETRANS                       32772
#define ID_FILE_DOWNLOAD                32773
#define DOWNLOAD                        32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
