﻿// CFileManger.cpp: 实现文件
//

#include "pch.h"
#include "RemoteCtrl.h"
#include "afxdialogex.h"
#include "CFileManger.h"


extern SSL* g_sslHandle;
extern map<SSL*, string>g_mapSSLHandle_IP;
//int g_nLine = 0;
// CFileManger 对话框

IMPLEMENT_DYNAMIC(CFileManger, CDialogEx)

CFileManger::CFileManger(CWnd* pParent /*=nullptr*/)
	: CDialogEx(DLG_FILE, pParent)
{

}

CFileManger::~CFileManger()
{
}

void CFileManger::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, LIST_FILE, m_ListCtrl_FIle);
}


BEGIN_MESSAGE_MAP(CFileManger, CDialogEx)
	ON_MESSAGE(WM_DRIVER, ReceiveDriver)
	ON_MESSAGE(WM_FILES, ReceiveFiles)
	ON_MESSAGE(WM_DOWNLOAD, DownloadFile)
	ON_NOTIFY(NM_DBLCLK, LIST_FILE, &CFileManger::OnDblclkListFile)
	ON_BN_CLICKED(BT_UP, &CFileManger::OnBnClickedUp)
END_MESSAGE_MAP()


// CFileManger 消息处理程序


BOOL CFileManger::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化
	
	m_ListCtrl_FIle.InsertColumn(0, "Name", LVCFMT_LEFT, 200);
	m_ListCtrl_FIle.InsertColumn(1, "Date", LVCFMT_LEFT, 200);
	m_ListCtrl_FIle.InsertColumn(2, "Type", LVCFMT_LEFT, 200);
	m_ListCtrl_FIle.InsertColumn(3, "Size", LVCFMT_LEFT, 200);
	m_ListCtrl_FIle.SetExtendedStyle(m_ListCtrl_FIle.GetExtendedStyle() | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	return TRUE;  // return TRUE unless you set the focus to a control
				  // 异常: OCX 属性页应返回 FALSE
}

afx_msg LRESULT  CFileManger::ReceiveDriver(WPARAM wParam, LPARAM lParam)
{
	// TODO: Add your implementation code here.
	/*for (auto i : g_mapSSLHandle_IP)
	{
		AfxMessageBox(i.second.c_str());
	}*/
	Data* data = (Data*)wParam;
	int nLine = 0;
	char szDriver[3] = { 0 };
	for (int i = 0; i < sizeof(data->szMsg); i += 4) {
		if (data->szMsg[i] == NULL)
		{
			return 0;
		}
		memcpy(szDriver, data->szMsg + i, 2);
		m_ListCtrl_FIle.InsertItem(nLine, szDriver);
		nLine++;
	}
		
	return true;
}

afx_msg LRESULT  CFileManger::ReceiveFiles(WPARAM wParam, LPARAM lParam)
{
	// TODO: Add your implementation code here.
	Data* data = (Data*)wParam;

	int nIndex = 0;
	int end = 0;
	int nCount = 0;
	char szTime[20];
	FileInfo fileinfo;
	while(true)
	{
		
		string strTemp;
		memcpy(&fileinfo, data->szMsg + nCount, sizeof(fileinfo));
		if (fileinfo.name[0] == '\0')
		{
			return 0;
		}

		
		nIndex = m_ListCtrl_FIle.InsertItem(0, fileinfo.name);//name
		SYSTEMTIME st;
		FileTimeToSystemTime(&fileinfo.ftCreationTime, &st);
		sprintf_s(szTime,"%04d-%02d-%02d %02d:%02d:%02d",
			st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
		m_ListCtrl_FIle.SetItemText(nIndex,1, szTime);//time
		//convert size
		
		if (fileinfo.dwAttribute == 0)	//type
		{
			m_ListCtrl_FIle.SetItemText(nIndex, 2, "Directory");
			m_ListCtrl_FIle.SetItemText(nIndex, 3, "");//size
		}
		else
		{
			m_ListCtrl_FIle.SetItemText(nIndex, 2, "FIle");
			float fSize_MB = static_cast<float>(fileinfo.dwSize) / 1024.0 / 1024.0;
			strTemp = to_string(fSize_MB);
			strTemp += "MB";
			m_ListCtrl_FIle.SetItemText(nIndex, 3, strTemp.c_str());//size

		}
		nCount += sizeof(fileinfo);
		if (nCount / sizeof(fileinfo) == 10)
		{
			return 0;
		}
	
		//g_nLine++;

	}
		
	return true;
}
afx_msg LRESULT  CFileManger::DownloadFile(WPARAM wParam, LPARAM lParam)
{

}


void CFileManger::OnDblclkListFile(NMHDR* pNMHDR, LRESULT* pResult)
{
	//g_nLine = 0;
	CString strWdTx;
	GetWindowText(strWdTx);
	SSL* sslHandle;
	for (auto i : g_mapSSLHandle_IP)
	{
		if (i.second == strWdTx.GetBuffer())
		{
			sslHandle = i.first;
			break;
		}
	}
	
	
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: Add your control notification handler code here
	
	
	AES_CBC256 aes_send;
	Data data = { 2,"0"};//request path
	int nLine = m_ListCtrl_FIle.GetSelectionMark();//get select line
	string strTemp = m_ListCtrl_FIle.GetItemText(nLine, 2);
	if (strTemp != "Directory"&& strTemp!="")
	{
		return;
	}
	 strTemp = m_ListCtrl_FIle.GetItemText(nLine, 0);

	if (strTemp == ".."|| strTemp == ".")
	{
		return;
	}
	else
	{
		if (g_IPandpath[strWdTx.GetBuffer()].empty())
		{
			g_IPandpath[strWdTx.GetBuffer()] = strTemp;
		}
		else
		{
			strTemp = g_IPandpath[strWdTx.GetBuffer()] + "\\" + strTemp;
			g_IPandpath[strWdTx.GetBuffer()] = strTemp;
		}
		
		memcpy(data.szMsg, g_IPandpath[strWdTx.GetBuffer()].c_str(), g_IPandpath[strWdTx.GetBuffer()].length());
		aes_send.SSL_AES256_sendData(aes_send, data, sslHandle);
		m_ListCtrl_FIle.DeleteAllItems();
	}
	SetDlgItemText(EDT_PATH, g_IPandpath[strWdTx.GetBuffer()].c_str());
	*pResult = 0;
}


void CFileManger::OnBnClickedUp()
{
	
	CString strWdTx;
	GetWindowText(strWdTx);
	SSL* sslHandle;
	for (auto i : g_mapSSLHandle_IP)
	{
		if (i.second == strWdTx.GetBuffer())
		{
			sslHandle = i.first;
			break;
		}
	}
	AES_CBC256 aes_send;
	//g_nLine = 0;
	Data data = { 2,"0" };//request path
	
	string::size_type pos = g_IPandpath[strWdTx.GetBuffer()].find("\\");
	if (pos == std::string::npos)
	{
		Data data = { 1,"0" };
		m_ListCtrl_FIle.DeleteAllItems();
		aes_send.SSL_AES256_sendData(aes_send, data, sslHandle);
		g_IPandpath[strWdTx.GetBuffer()].clear();
		SetDlgItemText(EDT_PATH, g_IPandpath[strWdTx.GetBuffer()].c_str());
		return;
	}

	g_IPandpath[strWdTx.GetBuffer()] =
		g_IPandpath[strWdTx.GetBuffer()].substr(0, g_IPandpath[strWdTx.GetBuffer()].rfind("\\"));//not driver's up

	SetDlgItemText(EDT_PATH, g_IPandpath[strWdTx.GetBuffer()].c_str());
	m_ListCtrl_FIle.DeleteAllItems();
	memcpy(data.szMsg, g_IPandpath[strWdTx.GetBuffer()].c_str(), g_IPandpath[strWdTx.GetBuffer()].length());
	aes_send.SSL_AES256_sendData(aes_send, data, sslHandle);
}
