﻿#pragma once
#include "afxdialogex.h"
#include "SSLServer.h"

// CFileManger 对话框
#define WM_DRIVER WM_USER + 6
#define WM_FILES WM_USER + 7
#define WM_DOWNLOAD WM_USER + 8
class CFileManger : public CDialogEx
{
	DECLARE_DYNAMIC(CFileManger)

public:
	CFileManger(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~CFileManger();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = DLG_FILE };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_ListCtrl_FIle;
	virtual BOOL OnInitDialog();
	afx_msg LRESULT ReceiveDriver(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT ReceiveFiles(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT DownloadFile(WPARAM wParam, LPARAM lParam);
	afx_msg void OnDblclkListFile(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBnClickedUp();
};
