#ifndef _HEADERNAME_H
#define _HEADERNAME_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/ssl.h>
#include <openssl/aes.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#include <stddef.h>
#include <string>
#include <iostream>
#include <sstream>
#include <ostream>
#include <Winsock2.h>
#include <stdio.h>
#include <Windows.h>
#include <vector>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <unordered_map>
#include "Package.h"
#pragma comment(lib, "ws2_32.lib") 
#pragma comment(lib, "libssl.lib")
#pragma comment(lib, "libcrypto.lib")
#define SERVER_ONLY 1
#define SERVER_ONLY__SERVER 2
#define BUFFER_SIZE 1024
using namespace std;

typedef struct tagPC_INFO
{
	char szOS[20];
	char szCPU[20];
	char szDISK[50];
	char szPC_NAME[20];
	char szCURRENT_USER[20];
}PC_INFO;

typedef struct tagData_pack
{
	int nFlag;
	unsigned char szMsg[1024] = { 0 };

}Data;


bool InitialWincock();

void handle_error(const char* file, int line, const char* msg);
bool Verify_cert(int nFlag, SSL_CTX* sslContext, const char* szCacert, const char* szCertf, const char* szKeyf);

#endif