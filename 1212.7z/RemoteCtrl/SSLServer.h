#pragma once
#include <AES_CBC256.h>
#include <map>
#define CERTF   "server.crt" 
#define KEYF   "server.key" 
#define CACERT "ca.crt"
#define WM_CLIENTONLINE WM_USER + 5
SOCKET g_sockListen;
SSL_CTX* g_sslContext;
SSL* g_sslHandle;
mutex g_mutex;
map<SSL*, string> g_mapSSLHandle_IP;
std::vector<thread> g_threads;//Store thread
class SSLConnection {
private:

	AES_CBC256 m_pcAES_CBC256;
	string strMessage;
	char szMessage[BUFFER_SIZE] = { 0 };

public:
	SSLConnection(int nPort) {
		
		//SSL initialize
		SSL_load_error_strings();//debug info
		SSL_library_init();

		// sslcontxt
		g_sslContext = SSL_CTX_new(SSLv23_server_method());
		if (g_sslContext == nullptr)
		{
			ERR_print_errors_fp(stderr);
			closesocket(g_sockListen);
			WSACleanup();
			return ;
		}

		// load cert
		if (!Verify_cert(SERVER_ONLY__SERVER, g_sslContext, CACERT, CERTF, KEYF))
		{
			MessageBox(0,"Verify_cert Failed",0,MB_OK);
		}

		//socket
		g_sockListen = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		//bind ip&port
		SOCKADDR_IN addrSrv;
		memset(&addrSrv, 0, sizeof(addrSrv));
		addrSrv.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
		addrSrv.sin_family = AF_INET;
		addrSrv.sin_port = htons(nPort);
		if(bind(g_sockListen, (SOCKADDR*)&addrSrv, sizeof(SOCKADDR)) == SOCKET_ERROR)
		{
			    std::cerr << "bind failed." << std::endl;
			    closesocket(g_sockListen);
			    WSACleanup();
			    return ;
		}
		//Listen
		if (listen(g_sockListen, SOMAXCONN) == SOCKET_ERROR)
		{
			std::cerr << "listen failed." << std::endl;
			closesocket(g_sockListen);
			WSACleanup();
			return;
		}
		std::cout << "server is listening on port : " << nPort << "..." << std::endl;


		


		thread accept_thread(&SSLConnection::accept_connections);
		accept_thread.detach();
		
	}
	 
	~SSLConnection() {
	
	/*SSL_shutdown(sslHandle);
	SSL_free(sslHandle);
	SSL_CTX_free(sslContext);
	closesocket(sockListen);*/

	}
	SOCKET getSocketListen()
	{
		return g_sockListen;
	}
	SSL_CTX *getSSLContext()
	{
		return g_sslContext;
	}
	SSL* getSSLHandle()
	{
		return g_sslHandle;
	}

	static void accept_connections() {
		
		
		HWND hWnd = ::FindWindow(NULL, "Server");
		if (hWnd == nullptr)
		{
			MessageBox(0, "FindWindow Failed", "error", MB_OK);
			return;
		}

		while (true)
		{
			//get client info
			SOCKADDR_IN addrSrv;
			memset(&addrSrv, 0, sizeof(addrSrv));

		
			int nSockClientLen = sizeof(SOCKADDR);
			SOCKET socketClient = accept(g_sockListen, (SOCKADDR*)&addrSrv, &nSockClientLen);
		//	cout << "conneted : ip=>" << inet_ntoa(addrSrv.sin_addr)<< ": " << addrSrv.sin_port << endl;
			char szSocket_Ip[22] = { 0 };
			sprintf(szSocket_Ip, "%s:%d", inet_ntoa(addrSrv.sin_addr), addrSrv.sin_port);
			int nLen = strlen(szSocket_Ip);
			szSocket_Ip[nLen] = '\0';
			string strTemp = szSocket_Ip;
			

			if (socketClient == INVALID_SOCKET)
			{
				std::cerr << "accept failed." << std::endl;
				closesocket(g_sockListen);
				WSACleanup();
				return;
			}
			g_sslHandle = SSL_new(g_sslContext);
	
			if (g_sslHandle == nullptr)
			{
				std::cerr << "SSL_new Failed" << std::endl;
			}
			int nRet = SSL_set_fd(g_sslHandle, socketClient);
			nRet = SSL_accept(g_sslHandle);
			g_mapSSLHandle_IP[g_sslHandle] = strTemp;//insert SSLHandle.IP
			if (nRet == -1)
			{
				nRet = SSL_get_error(g_sslHandle, nRet);
				handle_error(__FILE__, __LINE__, "SSL_connect() failed");
				ERR_print_errors_fp(stderr);
				SSL_shutdown(g_sslHandle);
				closesocket(g_sockListen);
				return;
			} 
			
			//Recv LoginPackage
			PC_INFO *pc_info = new PC_INFO;
			AES_CBC256 AES_CBC256;
			int bytesRecv = AES_CBC256.SSL_AES256_recvData(AES_CBC256, pc_info, g_sslHandle);

			if (!::PostMessage(hWnd, WM_CLIENTONLINE, (WPARAM) (&szSocket_Ip), (LPARAM)pc_info))
			{
				MessageBox(0, "Login Failed", "error", MB_OK);
			}
			/*string strLogin;
		
			char szMsg[200] = { 0 };
			int bytesRecv = AES_CBC256.SSL_AES256_recvData(AES_CBC256, strLogin, g_sslHandle);
			strLogin.reserve(bytesRecv);
			
			istringstream iss;
			strLogin.resize(bytesRecv);
			iss.str(strLogin);
			iss.read(reinterpret_cast<char*>(&pc_info), sizeof(pc_info));
*/

			g_threads.emplace_back(handle_client, socketClient, g_sslHandle);
			
			/*std::thread client_thread(&SSLConnection::handle_client);
			client_thread.detach();*/

		}

	}

	 static void handle_client(int socketClient,SSL *ssl) {
		 
		 while (true)
		 {
			 //lock_guard<mutex> lock(g_mutex);
			 char Buffer[BUFFER_SIZE] = { 0 };
			 string strbuffer;
			 Data data = { 0 };
			 AES_CBC256 m_pcAES_CBC256;
			 m_pcAES_CBC256.SSL_AES256_recvData(m_pcAES_CBC256, data, ssl);
			
	
				 
				 string strSend = "I have received ";
				 strSend += strbuffer;
				 strSend += string(" from ");
				 strSend += to_string(socketClient);
				 memcpy(data.szMsg, strSend.c_str(), strSend.length());
				 m_pcAES_CBC256.SSL_AES256_sendData(m_pcAES_CBC256, data, ssl);
				 cout << "Send to "<< socketClient << " OK" << endl;
			 

		 }
			
	}


};
