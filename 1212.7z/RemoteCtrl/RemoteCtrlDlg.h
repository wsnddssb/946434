
// RemoteCtrlDlg.h : header file
//

#pragma once


// CRemoteCtrlDlg dialog
class CRemoteCtrlDlg : public CDialogEx
{
// Construction
public:
	CRemoteCtrlDlg(CWnd* pParent = nullptr);	// standard constructor
	afx_msg LRESULT ClientLogin(WPARAM wParam, LPARAM lParam);
// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_REMOTECTRL_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	DECLARE_MESSAGE_MAP()
public:
	CListCtrl m_CListCtrl_Client;
	afx_msg void OnSize(UINT nType, int cx, int cy);
	CListCtrl m_CListCtrl_Info;
	void InitialList();
	bool ClientLogin();
	afx_msg void OnBnClickedStart();
	afx_msg void OnRclickListClient(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFiletrans();
};
