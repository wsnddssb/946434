#include "ClientInitial.h"
SSL_CTX* SSL_Initialize()
{
	//Load error info
	ERR_load_ERR_strings();
	ERR_load_crypto_strings();

	//SSL initialize
	SSL_load_error_strings();
	SSL_library_init();
	SSL_CTX* sslContext = SSL_CTX_new(SSLv23_client_method());
	if (sslContext == nullptr)
	{
		cerr << "SSL_CTX_new failed" << endl;
		return 0;
	}
	Verify_cert(SERVER_ONLY, sslContext, NULL, NULL, NULL);
	return sslContext;
}
int Winsock_init(WORD wVersionRequested, WSADATA* wsaData)
{
	if (WSAStartup(wVersionRequested, wsaData) != 0)
	{
		cerr << "Winsock initialize failed!" << endl;
		return EXIT_FAILURE;
	}


	if (LOBYTE(wsaData->wVersion) != 1 || HIBYTE(wsaData->wVersion) != 1)
	{
		WSACleanup();
		return EXIT_FAILURE;
	}
	return 0;
}
string getCpuInfo()
{

	int cpuInfo[4] = { 0 };
	char cpu_type[32] = { 0 };
	string strCpuType;
	__cpuid(cpuInfo, 0x80000003);
	memcpy(cpu_type, ((char*)cpuInfo) + 2, sizeof(cpuInfo) - 2);
	strCpuType = cpu_type;
	return strCpuType;

}
string getOsInfo()
{
	// get os name according to version number
	OSVERSIONINFO osver = { sizeof(OSVERSIONINFO) };
	GetVersionEx(&osver);
	std::string os_name;
	if (osver.dwMajorVersion == 5 && osver.dwMinorVersion == 0)
		os_name = "Windows 2000 ";
	else if (osver.dwMajorVersion == 5 && osver.dwMinorVersion == 1)
		os_name = "Windows XP ";
	else if (osver.dwMajorVersion == 6 && osver.dwMinorVersion == 0)
		os_name = "Windows 2003 ";
	else if (osver.dwMajorVersion == 5 && osver.dwMinorVersion == 2)
		os_name = "windows vista ";
	else if (osver.dwMajorVersion == 6 && osver.dwMinorVersion == 1)
		os_name = "windows 7 ";
	else if (osver.dwMajorVersion == 6 && osver.dwMinorVersion == 2)
		os_name = "windows 10 ";
	string str_OSIFO = os_name;
	str_OSIFO += to_string(osver.dwMajorVersion);
	str_OSIFO += ". ";
	str_OSIFO += to_string(osver.dwMinorVersion);
	return str_OSIFO;

}
string GetPCName()
{
	TCHAR name[MAX_COMPUTERNAME_LENGTH + 1];
	DWORD size = MAX_COMPUTERNAME_LENGTH + 1;
	(GetComputerName(name, &size));
	string strName = name;
	return strName;
}
string GetDisk()
{
	//getDisk
	string strDisk;
	ULARGE_INTEGER free_bytes, total_bytes, total_free_bytes;
	if (GetDiskFreeSpaceEx(NULL, &free_bytes, &total_bytes, &total_free_bytes)) {
		strDisk = to_string(free_bytes.QuadPart / 1024 / 1024);
		strDisk += "MB /";
		strDisk += to_string(total_bytes.QuadPart / 1024 / 1024);
		strDisk += " MB";
		return strDisk;
	}
	return strDisk;
}
string GetCurrentUserName()
{
	//urrent username
	TCHAR tName[10 + 1];
	DWORD dwSize = 10 + 1;
	if (GetUserName(tName, &dwSize)) {
		string strName = tName;
		return strName;
	}
}