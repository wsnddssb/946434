#include "Powershell.h"

Powershell::Powershell(void)
{
	m_hChildInputWrite = NULL;
	m_hChildInputRead = NULL;
	m_hChildOutputWrite = NULL;
	m_hChildOutputRead = NULL;
	ZeroMemory(&pi, sizeof(pi));
}

Powershell::~Powershell(void)
{
	ShutDownCmd();
}
bool Powershell::StartCmd(const string& process)
{
	SECURITY_ATTRIBUTES   sa;
	sa.bInheritHandle = TRUE;
	sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(sa);

	//create output pipe 
	if (FALSE == ::CreatePipe(&m_hChildOutputRead, &m_hChildOutputWrite, &sa, 0))
	{
		return false;
	}

	//create input pipe 
	if (FALSE == CreatePipe(&m_hChildInputRead, &m_hChildInputWrite, &sa, 0))
	{
		::CloseHandle(m_hChildOutputWrite);
		::CloseHandle(m_hChildOutputRead);
		::CloseHandle(m_hChildOutputWrite);
		::CloseHandle(m_hChildOutputRead);
		return false;
	}

	ZeroMemory(&pi, sizeof(pi));
	STARTUPINFO  si;
	GetStartupInfo(&si);

	si.cb = sizeof(STARTUPINFO);
	si.dwFlags |= STARTF_USESTDHANDLES ;
	si.wShowWindow = SW_HIDE;
	si.hStdInput = m_hChildInputRead;     
	si.hStdOutput = m_hChildOutputWrite;   
	si.hStdError = m_hChildOutputWrite;

	if (FALSE == ::CreateProcess(NULL, (LPSTR)(process.c_str()), NULL, NULL, TRUE, NORMAL_PRIORITY_CLASS, NULL, NULL, &si, &pi))
	{
		::CloseHandle(m_hChildInputWrite);
		::CloseHandle(m_hChildInputRead);
		::CloseHandle(m_hChildOutputWrite);
		::CloseHandle(m_hChildOutputRead);
		m_hChildInputWrite = NULL;
		m_hChildInputRead = NULL;
		m_hChildOutputWrite = NULL;
		m_hChildOutputRead = NULL;
		ZeroMemory(&pi, sizeof(pi));
		return false;
	}

	return true;
}
bool Powershell::ShutDownCmd(void)
{
	::CloseHandle(m_hChildInputWrite);
	::CloseHandle(m_hChildInputRead);
	::CloseHandle(m_hChildOutputWrite);
	::CloseHandle(m_hChildOutputRead);

	m_hChildInputWrite = NULL;
	m_hChildInputRead = NULL;
	m_hChildOutputWrite = NULL;
	m_hChildOutputRead = NULL;

	::TerminateProcess(pi.hProcess, -1);
	::CloseHandle(pi.hProcess);
	::CloseHandle(pi.hThread);
	ZeroMemory(&pi, sizeof(pi));
	return true;
}

bool Powershell::GetOutput(const string& strEnd, int nTimeout, string& strOut)
{
	if (NULL == m_hChildOutputRead)
	{
		return false;
	}

	strOut = "";
	char szBuffer[4096] = { 0 };
	DWORD dwReadBytes = 0;
	while (nTimeout > 0)
	{
		//read data of pipe(no data then return)
		if (FALSE == PeekNamedPipe(m_hChildOutputRead, szBuffer, sizeof(szBuffer) - 1, &dwReadBytes, 0, NULL))
		{
			return false;
		}

		//wait for data
		if (0 == dwReadBytes)
		{
			::Sleep(200);
			nTimeout -= 200;
			continue;
		}

		dwReadBytes = 0;
		if (::ReadFile(m_hChildOutputRead, szBuffer, sizeof(szBuffer) - 1, &dwReadBytes, NULL))
		{
			strOut.insert(strOut.end(), szBuffer, szBuffer + dwReadBytes);
			size_t nPos = strOut.rfind(strEnd);
			if (string::npos == nPos)
			{
				continue;
			}
			if (nPos == strOut.size() - strEnd.size())
			{
				return true;//find data
			}
		}
		else
		{
			return false;
		}
	}

	return false;
}

bool Powershell::Input(const string& cmd)
{
	if (NULL == m_hChildInputWrite)
	{
		return "";
	}

	string strTmp = cmd + "\r\n";
	DWORD dwWriteBytes = 0;
	if (FALSE == ::WriteFile(m_hChildInputWrite, strTmp.c_str(), strTmp.size(), &dwWriteBytes, NULL))
	{
		return false;
	}
	return true;
}


